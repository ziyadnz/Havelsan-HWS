---
name: Feature request
about: Got a great idea for feature?
title: ''
labels: Feature
assignees: ''

---

**It would be great if ICEcoder....**
Explain your idea here. The more info the better if it's a complicated feature. Be sure to suggest something many people would like however!

**Describe alternatives you've considered**
A clear and concise description of any alternative solutions or features you've considered.

**Additional context**
Add any other context or screenshots about the feature request here.
