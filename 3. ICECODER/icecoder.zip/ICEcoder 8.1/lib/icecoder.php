<?php
// Classes
require_once "../classes/_ExtraProcesses.php";
require_once "../classes/Backup.php";
require_once "../classes/File.php";
require_once "../classes/Settings.php";
require_once "../classes/System.php";
require_once "../classes/URL.php";

// Headers & Settings
require_once "headers.php";
require_once "settings.php";
